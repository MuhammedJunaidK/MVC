<nav class="navbar navbar-expand-lg navbar-light bg-light border-top">
          <div class="container m-auto">
            <a href="#" class="m-auto" style="text-decoration: none;">Developed by Dev Ninja</a>
          </div>
        </nav>