<?php
session_start();
$db=mysqli_connect('localhost','root','','myblog') or die("Database is not connected !");
?>